    var xhr = new XMLHttpRequest();
    let url = "https://www.dreadcast.net/Main"
    xhr.open("GET", url, true)
    xhr.setRequestHeader("Content-Type", "application/json")
    xhr.send()
    
    xhr.onreadystatechange = function() {
        console.log(xhr.responseText);
        if (xhr.readyState === 4) {
              if(xhr.readyState === 4 && xhr.status === 200) {
        console.log(xhr.responseText);
              }
        }
    }
