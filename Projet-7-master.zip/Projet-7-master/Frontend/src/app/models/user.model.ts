export class user {
	imageUrl: string;
	password: string;
}
