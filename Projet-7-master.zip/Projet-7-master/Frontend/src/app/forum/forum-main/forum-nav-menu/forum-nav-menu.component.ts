import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forum-nav-menu',
  templateUrl: './forum-nav-menu.component.html',
  styleUrls: ['./forum-nav-menu.component.sass']
})
export class ForumNavMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
