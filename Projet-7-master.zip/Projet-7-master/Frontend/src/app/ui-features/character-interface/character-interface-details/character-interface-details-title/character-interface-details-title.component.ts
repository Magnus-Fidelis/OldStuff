import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-character-interface-details-title',
  templateUrl: './character-interface-details-title.component.html',
  styleUrls: ['./character-interface-details-title.component.sass']
})
export class CharacterInterfaceDetailsTitleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
