import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-character-interface-details-cybernetic',
  templateUrl: './character-interface-details-cybernetic.component.html',
  styleUrls: ['./character-interface-details-cybernetic.component.sass']
})
export class CharacterInterfaceDetailsCyberneticComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
