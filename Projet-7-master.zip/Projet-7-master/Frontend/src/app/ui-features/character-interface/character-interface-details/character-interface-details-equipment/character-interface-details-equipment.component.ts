import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-character-interface-details-equipment',
  templateUrl: './character-interface-details-equipment.component.html',
  styleUrls: ['./character-interface-details-equipment.component.sass']
})
export class CharacterInterfaceDetailsEquipmentComponent implements OnInit {



  constructor() { }

  ngOnInit(): void {
  }

}
