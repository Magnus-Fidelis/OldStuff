import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-character-interface-details-statistics',
  templateUrl: './character-interface-details-statistics.component.html',
  styleUrls: ['./character-interface-details-statistics.component.sass']
})
export class CharacterInterfaceDetailsStatisticsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
