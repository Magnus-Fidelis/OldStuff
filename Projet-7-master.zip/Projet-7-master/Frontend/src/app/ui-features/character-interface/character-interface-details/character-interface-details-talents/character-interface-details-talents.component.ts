import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-character-interface-details-talents',
  templateUrl: './character-interface-details-talents.component.html',
  styleUrls: ['./character-interface-details-talents.component.sass']
})
export class CharacterInterfaceDetailsTalentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
