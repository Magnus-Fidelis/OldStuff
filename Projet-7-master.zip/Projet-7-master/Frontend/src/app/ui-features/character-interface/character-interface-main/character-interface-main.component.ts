import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-character-interface-main',
  templateUrl: './character-interface-main.component.html',
  styleUrls: ['./character-interface-main.component.sass']
})
export class CharacterInterfaceMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
